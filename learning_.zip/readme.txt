learningディレクトリを入れたいディレクトリ/learning_
の中で以下のコマンドを実施する
echo 'export PATH="$HOME/bin:$PATH"' >> ~/.bashrc
source ~/.bashrc
mkdir ~/bin
mv * ..
cd ..
rm -r learning_
mkdir learning
chmod 777 learning_setup
mv learning_setup ~/bin
learning_setup
rm ~/bin/learning_setup
cd learning
chmod 777 ~/bin/learning_pull.sh
learning_pull.sh
cd ..
cd learning
今後、内容を更新したいときは、learning_pull.shを実行すると最新のデータになる
ターミナル上では、learningディレクトリの中に何もない表記になっていたら、ディレクトリを入り直すと治る
